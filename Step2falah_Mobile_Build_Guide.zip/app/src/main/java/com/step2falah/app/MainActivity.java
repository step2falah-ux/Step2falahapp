package com.step2falah.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    final int bg = Color.rgb(4, 39, 32);
    final int green = Color.rgb(0, 116, 76);
    final int mint = Color.rgb(35, 225, 166);
    final int white = Color.WHITE;
    EditText link;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showSplash();
    }

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
    }

    void showSplash() {
        LinearLayout root = new LinearLayout(this);
        root.setGravity(Gravity.CENTER); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(30), dp(24), dp(30));
        GradientDrawable gradient = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(2,35,28), Color.rgb(0,100,66), Color.rgb(2,25,25)});
        root.setBackground(gradient);

        TextView crescent = text("☾", 45, mint, true);
        crescent.setGravity(Gravity.CENTER);
        root.addView(crescent, lp(-1, 58));

        TextView icon = text("▶", 48, white, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(shape(green, mint, 30));
        root.addView(icon, lp(116, 116));

        TextView name = text("Step2falah", 32, white, true);
        name.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams nlp = lp(-1, 52); nlp.topMargin = dp(15);
        root.addView(name, nlp);

        TextView tagline = text("علم • عمل • فلاح", 17, mint, true);
        tagline.setGravity(Gravity.CENTER);
        root.addView(tagline, lp(-1, 34));

        TextView loading = text("WATCH  •  DOWNLOAD  •  SAVE", 12, Color.rgb(213,255,239), true);
        loading.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = lp(-1, 40); tlp.topMargin = dp(22);
        root.addView(loading, tlp);

        icon.startAnimation(new ScaleAnimation(.75f,1.0f,.75f,1.0f,
            Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f));
        icon.getAnimation().setDuration(900);
        icon.getAnimation().setRepeatMode(Animation.REVERSE);
        icon.getAnimation().setRepeatCount(Animation.INFINITE);
        AlphaAnimation fade = new AlphaAnimation(.45f,1f);
        fade.setDuration(1100); fade.setRepeatMode(Animation.REVERSE); fade.setRepeatCount(Animation.INFINITE);
        crescent.startAnimation(fade);

        setContentView(root);
        root.postDelayed(this::showHome, 1700);
    }

    void showHome() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(24));
        page.setBackgroundColor(Color.rgb(244,250,247));
        scroll.addView(page);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(15), dp(16), dp(15));
        header.setBackground(shape(bg, 0, 22));
        TextView logo = text("▶", 25, mint, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(shape(green, mint, 15));
        header.addView(logo, lp(52,52));
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(12),0,0,0);
        brand.addView(text("Step2falah", 22, white, true));
        brand.addView(text("Watch • Download • Save", 11, Color.rgb(185,240,218), false));
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(text("☾", 26, mint, true));
        page.addView(header, lp(-1,-2));

        TextView headline = text("آپ کی ویڈیوز، ایک جگہ", 23, bg, true);
        headline.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams hlp = lp(-1,-2); hlp.topMargin=dp(24);
        page.addView(headline, hlp);
        TextView sub = text("لنک پیسٹ کریں اور ویڈیو کھولیں", 14, Color.rgb(82,105,94), false);
        sub.setGravity(Gravity.RIGHT);
        page.addView(sub, lp(-1,32));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(16),dp(17),dp(16),dp(17));
        panel.setBackground(shape(white, Color.rgb(210,231,219), 20));
        LinearLayout.LayoutParams plp = lp(-1,-2); plp.topMargin=dp(12);
        page.addView(panel, plp);

        panel.addView(text("ویڈیو لنک", 15, bg, true), lp(-1,28));
        link = new EditText(this);
        link.setSingleLine(true); link.setTextSize(14); link.setHint("https://www.youtube.com/...");
        link.setPadding(dp(12),dp(10),dp(12),dp(10));
        link.setBackground(shape(Color.rgb(247,251,248), Color.rgb(195,220,205), 13));
        LinearLayout.LayoutParams elp = lp(-1,52); elp.topMargin=dp(8);
        panel.addView(link, elp);

        Button open = new Button(this); open.setText("▶   ویڈیو کھولیں");
        open.setTextColor(white); open.setAllCaps(false); open.setTextSize(16);
        open.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        LinearLayout.LayoutParams olp=lp(-1,54); olp.topMargin=dp(13);
        panel.addView(open, olp);
        open.setOnClickListener(v -> openLink());

        TextView featureTitle = text("اہم فیچرز", 20, bg, true);
        featureTitle.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams ftp=lp(-1,38); ftp.topMargin=dp(22);
        page.addView(featureTitle,ftp);

        addFeature(page, "▶", "ویڈیوز دیکھیں", "لنک سے ویڈیو YouTube یا براؤزر میں کھولیں");
        addFeature(page, "↓", "اجازت یافتہ ڈاؤن لوڈز", "اپنی یا ڈاؤن لوڈ کی اجازت والی ویڈیوز کے لیے");
        addFeature(page, "♡", "پسندیدہ ویڈیوز", "اپنی پسند کی ویڈیوز کے لنکس محفوظ رکھنے کا اگلا مرحلہ");
        addFeature(page, "◷", "ویڈیو ہسٹری", "سادہ اور صاف ستھرا اسلامی سبز تھیم");

        TextView notice = text("نوٹ: یہ ابتدائی ورژن لنک کھولتا ہے۔ YouTube کی ہر ویڈیو ڈاؤن لوڈ کرنے کی سہولت شامل نہیں، اور پابندیوں کو بائی پاس نہیں کرتا۔", 12, Color.rgb(59,83,70), false);
        notice.setPadding(dp(14),dp(13),dp(14),dp(13));
        notice.setBackground(shape(Color.rgb(224,242,231),0,15));
        LinearLayout.LayoutParams n=lp(-1,-2); n.topMargin=dp(16);
        page.addView(notice,n);

        TextView footer=text("STEP2FALAH  •  علم، عمل، فلاح",11,Color.GRAY,true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fl=lp(-1,42); fl.topMargin=dp(10);
        page.addView(footer,fl);

        AlphaAnimation enter = new AlphaAnimation(0f,1f); enter.setDuration(500);
        page.startAnimation(enter);
        setContentView(scroll);
    }

    void addFeature(LinearLayout page, String symbol, String title, String desc) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(13),dp(12),dp(13),dp(12));
        card.setBackground(shape(white,Color.rgb(222,236,227),16));
        TextView ico=text(symbol,25,green,true); ico.setGravity(Gravity.CENTER);
        ico.setBackground(shape(Color.rgb(224,245,234),0,13));
        card.addView(ico,lp(48,48));
        LinearLayout words=new LinearLayout(this); words.setOrientation(LinearLayout.VERTICAL);
        words.setPadding(dp(12),0,0,0);
        words.addView(text(title,15,bg,true));
        TextView detail=text(desc,11,Color.rgb(93,112,101),false);
        words.addView(detail);
        card.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams cp=lp(-1,-2); cp.topMargin=dp(8);
        page.addView(card,cp);
    }

    void openLink() {
        String value=link.getText().toString().trim();
        if(value.isEmpty()) { Toast.makeText(this,"پہلے ویڈیو لنک پیسٹ کریں",Toast.LENGTH_SHORT).show(); return; }
        Uri uri=Uri.parse(value);
        String scheme=uri.getScheme();
        if(uri.getHost()==null || scheme==null || !(scheme.equals("https") || scheme.equals("http"))) {
            Toast.makeText(this,"درست http یا https لنک درج کریں",Toast.LENGTH_LONG).show(); return;
        }
        try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); }
        catch(Exception e) { Toast.makeText(this,"لنک نہیں کھل سکا",Toast.LENGTH_LONG).show(); }
    }
}
